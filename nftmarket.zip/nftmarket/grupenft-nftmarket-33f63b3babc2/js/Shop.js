// Get all Edit buttons
const editButtons = document.querySelectorAll('.edit-button');

// Get the modal element
const modal = document.getElementById('editModal');

// Get the modal form elements
const modalName = document.getElementById('modalName');
const modalPrice = document.getElementById('modalPrice');
const modalDescription = document.getElementById('modalDescription');
const modalSubmit = document.getElementById('modalSubmit');

// Loop through all Edit buttons and add a click event listener
editButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Get the product information from the button's data attributes
    const id = button.dataset.id;
    const name = button.dataset.name;
    const price = button.dataset.price;
    const description = button.dataset.description;

    // Set the modal form values
    modalName.value = name;
    modalPrice.value = price;
    modalDescription.value = description;

    // Show the modal
    modal.style.display = 'block';

    // Set the focus on the modal name input field
    modalName.focus();
  });
});
