<?php
    session_start();

    // Patikriname, ar vartotojas prisijungęs
    if(!isset($_SESSION['username'])) {
        header('Location: login.php');
        exit();
    }

    require_once('db_config.php');
    $con = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (!$con) {
        die("Connection Error");
    }

    $username = $_SESSION['username'];

    // Iš duomenų bazės gauname vartotojo informaciją pagal vartotojo vardą
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($con, $query);
    $user = mysqli_fetch_assoc($result);

    // Jei vartotojas nori pakeisti slaptažodį, vykdome šias procedūras
    if (isset($_POST['old_password']) && isset($_POST['new_password'])) {
        $oldPassword = $_POST['old_password'];
        $newPassword = $_POST['new_password'];
        $userId = $user['id'];

        // Patikriname, ar senas slaptažodis teisingas
        if (password_verify($oldPassword, $user['password'])) {
            // Naujas slaptažodis
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Keičiame vartotojo slaptažodį duomenų bazėje
            $query = "UPDATE users SET password = '$hashedPassword' WHERE id = $userId";
            mysqli_query($con, $query);
            $_SESSION['successMessage'] = "Slaptažodis sėkmingai pakeistas!";
            header('location: ../index.php');
            exit();
        } else {
            $errorMessage = "Senas slaptažodis neteisingas!";
        }
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Slaptažodžio Keitimas</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/Recovery.css">

</head>
<body>
    <?php if(isset($errorMessage)): ?>
        <p class="error"><?php echo $errorMessage; ?></p>
    <?php endif; ?>

    <div id="SignIn-form">
        <h2>Keisti slaptažodį</h2>

        <form action="#" method="post">
            <label for="old_password">Senas slaptažodis</label>
            <input type="password" id="old_password" name="old_password" required autocomplete="off">

            <label for="new_password">Naujas slaptažodis</label>
            <input type="password" id="new_password" name="new_password" required autocomplete="off">

            <input type="submit" name="submit" value="Keisti">
        </form>
    </div>
</body>
</html>
