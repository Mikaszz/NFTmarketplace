<?php
    session_start();
    $currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NFT Shop</title>
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/Shop.css">
    <link rel="stylesheet" href="../css/Listings.css">
    <script src="https://kit.fontawesome.com/4a94b1e09e.js" crossorigin="anonymous"></script>
</head>
<body>
<section id="header">
    <a href="../index.php"><img src="../img/logo.jpg"></a>
    <div>
        <ul id="navbar">
            <?php if($currentPage == 'listings.php') { ?>
                <li><a class="active" href="../php/listings.php">My Listings</a></li>
            <?php } else { ?>
                <li><a href="../php/listings.php">My Listings</a></li>
            <?php } ?>
            <?php if(!isset($_SESSION['username'])) { ?>
                <li id="login_li"><a href="../html/login.php">Login</a></li>
                <li id="register_li"><a href="../html/register.php">Register</a></li>
            <?php } elseif($_SESSION['auth_level'] == 1) { ?>
                <li id="moderate_li"><a href="">Moderate</a></li>
            <?php } else { ?>
                <li><a href="../index.php">Shop</a></li>
                <li id="profile_li"><a href="../php/profile.php"><i class="fa-solid fa-user" ></i> <?php echo $_SESSION['username'] ?></a></li>
                <li id="logout_li"><a href="../php/logout.php">Logout</a></li>
                <li id="basket_li"><a href=""><i class="fa-solid fa-basket-shopping fa-2xl"></i></a></li>
            <?php } ?>
        </ul>
    </div>
</section>
<form method="POST" action="process_listing.php" enctype="multipart/form-data" onsubmit="window.close();">
    <label for="image">Image:</label>
    <input type="file" id="image" name="image" accept="image/*">
    <br>
    <label for="name">Name:</label>
    <input type="text" id="name" name="name">
    <br>
    <label for="description">Description:</label>
    <textarea id="description" name="description"></textarea>
    <br>
    <label for="price">Price:</label>
    <input type="text" id="price" name="price">
    <br>
    <input type="submit" value="Submit">
</form>
</body>
</html>
