<?php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/Recovery.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Abel&display=swap" rel="stylesheet">    <title>recovery</title>
</head>
<body>
    
    <div id="recovery-form">
        <h2>Password recovery</h2>
  
          <label for="email">Email</label>
          <input type="email" id="email" name="email" required autocomplete="off">
          <input type="submit" value="Submit">
          
        </form>
      </div>
    </div>

</body>
</html>
?>