<?php
    session_start();
    require_once('db_config.php');

    $username = null;
    $email = null;
    $password = null;
    $error_msg = null;
    $success_msg = null;

    $conn = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (!$conn) {
        die("Connection failed." . mysqli_connect_error());
    }

    if(isset($_POST['submit'])){
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        if (empty($username)) {
            $error_msg = "Username is required.";
        } elseif (!preg_match("/^(?!.*\.\.)(?!.*\.$)[^\W][\w.]{0,}$/im", $username)) {
            $error_msg = "Wrong username format.";
        } elseif (empty($email)) {
            $error_msg = "Email is required.";
        } elseif (!preg_match("/[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/", $email)) {
            $error_msg = "Wrong email format.";
        } elseif (empty($password)) {
            $error_msg = "Password is required.";
        } elseif (!preg_match("/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/m", $password)) {
            $error_msg = "Wrong password format. Must contain 1 uppercase, 1 lowercase letter and 1 number and be at least 8 characters long.";
        }

        $password = password_hash($password, PASSWORD_DEFAULT);

        $sql = "SELECT * FROM users WHERE email='$email' OR username='$username'";
        $result = mysqli_query($conn, $sql);
        
        if(mysqli_num_rows($result) > 0) {
            $error_msg = "Username or email already exists.";
        } elseif(!isset($error_msg)) {
            $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
            if(mysqli_query($conn, $sql)) {
                $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM users WHERE username = '$username'"));
                $_SESSION['username'] = $username;
                $_SESSION['auth_level'] = 0;
                $_SESSION['id'] = $row['id'];
                $_SESSION['status'] = "active";
                $success_msg = "Registration successful.";
                header("location: ../index.php");
            } else {
                $error_msg = "Error: " . mysqli_error($conn);
            }
        }
    }
    mysqli_close($conn);
?>