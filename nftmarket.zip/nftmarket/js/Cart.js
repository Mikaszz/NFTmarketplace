function toggleCart() {
    event.preventDefault();
    let element = document.getElementById("productsOnCart");
    let hidden = element.getAttribute("hidden");
    if (hidden) {
        element.removeAttribute("hidden");
     } else {
        element.setAttribute("hidden", "hidden");
     }
    }
