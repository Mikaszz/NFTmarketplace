// Get all Buy Now buttons
const buyButtons = document.querySelectorAll('.buy-button');

// Loop through all Buy Now buttons and add a click event listener
buyButtons.forEach(button => {
  button.addEventListener('click', () => {
    // Get the product information from the button's data attributes
    const id = button.dataset.id;
    const name = button.dataset.name;
    const price = button.dataset.price;
    const description = button.dataset.description;
    
    // Build the popup message
    const message = `Name: ${name}\nPrice: ${price}\nDescription: ${description}`;

    // Show the popup message
    alert(message);
  });
});
