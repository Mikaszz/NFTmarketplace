<?php
    session_start();

    // Patikriname, ar vartotojas prisijungęs
    if(!isset($_SESSION['username'])) {
        header('Location: login.php');
        exit();
    }

    require_once('db_config.php');
    $con = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (!$con) {
        die("Connection Error");
    }

    $username = $_SESSION['username'];

    // Iš duomenų bazės gauname vartotojo informaciją pagal vartotojo vardą
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($con, $query);
    $user = mysqli_fetch_assoc($result);

    // Jei vartotojas nori pakeisti slaptažodį, vykdome šias procedūras
    if (isset($_POST['old_password']) && isset($_POST['new_password'])) {
        $oldPassword = $_POST['old_password'];
        $newPassword = $_POST['new_password'];
        $userId = $user['id'];

        // Patikriname, ar senas slaptažodis teisingas
        if (password_verify($oldPassword, $user['password'])) {
            // Naujas slaptažodis
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Keičiame vartotojo slaptažodį duomenų bazėje
            $query = "UPDATE users SET password = '$hashedPassword' WHERE id = $userId";
            mysqli_query($con, $query);
            $successMessage = "Slaptažodis sėkmingai pakeistas!";
        } else {
            $errorMessage = "Senas slaptažodis neteisingas!";
        }
    }
    if (isset($_POST['new_username'])) {
        $newUsername = $_POST['new_username'];
        $userId = $user['id'];
    
        // Keičiame vartotojo vardą duomenų bazėje
        $query = "UPDATE users SET username = '$newUsername' WHERE id = $userId";
        mysqli_query($con, $query);
        $_SESSION['username'] = $newUsername;
        $successMessage = "Vardas sėkmingai pakeistas!";
    }    
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/Style.css">
    <title>Profilis</title>
    <meta charset="utf-8">
</head>
<body>
        

        <?php if(isset($successMessage)): ?>
            <p class="success"><?php echo $successMessage; ?></p>
        <?php endif; ?>

        <?php if(isset($errorMessage)): ?>
            <p class="error"><?php echo $errorMessage; ?></p>
        <?php endif; ?>

        <h2>Keisti vardą</h2>
        <form method="POST">
            <label for="new_username">Naujas vardas:</label>
            <input type="text" id="new_username" name="new_username" required>

            <button type="submit">Keisti vardą</button>
        </form>

        <h2>Keisti slaptažodį</h2>
        <form method="POST">
            <label for="old_password">Senas slaptažodis:</label>
            <input type="password" id="old_password" name="old_password" required>

            <label for="new_password">Naujas slaptažodis:</label>
            <input type="password" id="new_password" name="new_password" required>

            <button type="submit">Keisti slaptažodį</button>
        </form>
</body>
</html>
