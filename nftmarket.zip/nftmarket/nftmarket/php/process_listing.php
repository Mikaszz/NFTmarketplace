<?php
require_once('db_config.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['id'])) {
        echo "Error: You must be logged in to add a product.";
        exit();
    }

    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $image = $_FILES["image"]["name"];
    $tmp_name = $_FILES["image"]["tmp_name"];

    if (empty($name)) {
        echo "Error: Please enter a name for the product.";
        exit();
    }

    // Upload the image to imgur.com
    $client_id = "e6c288c207f5894";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.imgur.com/3/image');
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Client-ID ' . $client_id));
    curl_setopt($ch, CURLOPT_POSTFIELDS, array('image' => base64_encode(file_get_contents($tmp_name))));
    $response = curl_exec($ch);
    $response = json_decode($response);
    curl_close($ch);
    if ($response->success) {
        $image_link = $response->data->link;

        // Add the new product to the database
        $con = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if (!$con) {
            die("Connection Error");
        }

        // Get the user ID from the session variable
        $id = $_SESSION["id"];
        var_dump($id);

        // Insert new product into products table
        $insert_query = "INSERT INTO products (name, price, description, image, created_by_user_id) 
                         VALUES ('$name', '$price', '$description', '$image_link', '$id')";
        if (mysqli_query($con, $insert_query)) {
            echo "Product added successfully";
        } else {
            echo "Error: " . mysqli_error($con);
        }

        // Redirect back to the shop page
        header("Location: ../index.php");
        exit();
    } else {
        echo "Error uploading file";
    }
}
?>
