<?php
define('DB_HOST', '127.0.0.1');
define('DB_USERNAME', 'admin');
define('DB_PASSWORD', 'nimda');
define('DB_NAME', 'nftshop2');
?>