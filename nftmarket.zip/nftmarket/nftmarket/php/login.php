<?php
    session_start();
    require_once('db_config.php');

    $username = null;
    $password = null;
    $error_msg = null;

    $conn = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (!$conn) {
        die("Connection failed." . mysqli_connect_error());
    }

    if(isset($_POST['submit'])){
        $username = $_POST['name'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE username='$username'";
        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            if(password_verify($password, $row['password'])) {
                $_SESSION['username'] = $row['username'];
                $_SESSION['auth_level'] = $row['auth_level'];
                $_SESSION['id'] = $row['id'];
                $_SESSION['status'] = "active";
                header("location: ../index.php");
                exit();
            } else {
                $error_msg = "Incorrect password.";
            }
        } else {
            $error_msg = "User not found.";
        }
    }
    mysqli_close($conn);
?>