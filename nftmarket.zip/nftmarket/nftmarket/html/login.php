<?php require('../php/login.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/Login.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Abel&display=swap" rel="stylesheet">
    <title>Login</title>
</head>
<body>
    
    <div id="SignIn-form">
        <h2>Sign in</h2>

        <?php if(isset($error_msg)): ?>
            <p><?php echo $error_msg; ?></p>
        <?php endif; ?>

        <form action="" method="post">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required autocomplete="off">

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required autocomplete="off">

            <p>Don't have an account? <a id="SIGNUPSIGNIN" href="register.php">Sign up</a></p>

            <input type="submit" name="submit" value="Submit">
        </form>
    </div>

</body>
</html>