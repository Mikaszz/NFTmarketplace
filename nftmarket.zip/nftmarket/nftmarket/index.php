<?php
    session_start();

    require_once('./php/db_config.php');
    $con = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (!$con) {
        die("Connection Error");
    }
    // Handle search and sort queries
    if (isset($_GET['search'])) {
        $searchQuery = $_GET['search'];
        $query = "SELECT * FROM products WHERE name LIKE '%$searchQuery%'";
    } else {
        $query = "SELECT * FROM products";
    }

    if (isset($_GET['sort'])) {
        $sortBy = $_GET['sort'];
        if ($sortBy === 'price-asc') {
            $query .= " ORDER BY price ASC";
        } else if ($sortBy === 'price-desc') {
            $query .= " ORDER BY price DESC";
        } else if ($sortBy === 'name-asc') {
            $query .= " ORDER BY name ASC";
        } else if ($sortBy === 'name-desc') {
            $query .= " ORDER BY name DESC";
        }
    }

    $result = mysqli_query($con, $query);
    $nfts = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NFT Shop</title>
    <link rel="stylesheet" href="./css/header.css">
    <link rel="stylesheet" href="./css/Shop.css">
    <link rel="stylesheet" href="./css/Function.css">
    <script src="https://kit.fontawesome.com/4a94b1e09e.js" crossorigin="anonymous"></script>
</head>
<body>
<section id="header">
    <a href="index.php"><img src="img/logo.jpg"></a>
    <div>
        <ul id="navbar">
            <li><a class="active" href="">Shop</a></li>
            <?php if(!isset($_SESSION['username'])) { ?>
                <li id="login_li"><a href="html/login.php">Login</a></li>
                <li id="register_li"><a href="html/register.php">Register</a></li>
            <?php } elseif($_SESSION['auth_level'] == 1) { ?>
                <li id="moderate_li"><a href="">Moderate</a></li>
            <?php } else { ?>
                <li id="myListings_li"><a href="php/listings.php">My listings</a></li>
                <li id="profile_li"><a href="php/profile.php"><i class="fa-solid fa-user" ></i> <?php echo $_SESSION['username'] ?></a></li>
                <li id="logout_li"><a href="./php/logout.php">Logout</a></li>
                <li id="basket_li"><a href=""><i class="fa-solid fa-basket-shopping fa-2xl"></i></a></li>
            <?php } ?>
        </ul>
    </div>
</section>
<div class="container">

	<!-- Modal
	<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	        Modal body text goes here.
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-primary">Save changes</button>
	      </div>
	    </div>
	  </div>
	</div>
            -->
    <div class="row">
        <div class="col-12">
            <div class="sort-container">
                <a href="?sort=price-asc">Sort by Price (Low to High)</a>
                <a href="?sort=price-desc">Sort by Price (High to Low)</a>
                <a href="?sort=name-asc">Sort by Name (A to Z)</a>
                <a href="?sort=name-desc">Sort by Name (Z to A)</a>
            </div>
            <?php for ($i = 0; $i < count($nfts); $i += 4): ?>
    <div class="row justify-content-center">
        <?php for ($j = $i; $j < $i + 4 && $j < count($nfts); $j++): ?>
            <div class="col-md-2 mb-4">
                <div class="card">
                    <img class="card-img-top" src="<?php echo $nfts[$j]['image']; ?>" alt="<?php echo $nfts[$j]['name']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $nfts[$j]['name']; ?> <span class="id-number">#<?php echo $nfts[$j]['id']; ?></span></h5>
                        <p class="card-text">Price: <?php echo $nfts[$j]['price']; ?>€</p>
                        <div class="button-container">
                            <button class="btn btn-primary buy-button" data-id="<?php echo $nfts[$j]['id']; ?>" data-name="<?php echo $nfts[$j]['name']; ?>" data-price="<?php echo $nfts[$j]['price']; ?>" data-description="<?php echo $nfts[$j]['description']; ?>">Buy Now</button>
                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#editModal">Edit</button>
                        </div>
                    </div>
                </div>
              </div>
            </div>
          <?php endfor; ?>
        </div>
        <?php if ($j < count($nfts)): ?>
          <hr>
        <?php endif; ?>
      <?php endfor; ?>
    </div>
  </div>
</div>


<div class="search-container">
  <form action="index.php" method="GET">
    <input type="text" placeholder="Search products" name="search">
    <button type="submit"><i class="fa fa-search"></i></button>
  </form>
</div>

<script src="js/jquery-3.6.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/Shop.js"></script>

</body>
</html>