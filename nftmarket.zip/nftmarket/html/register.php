<?php require("../php/register.php") ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/Register.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Abel&display=swap" rel="stylesheet">    <title>Register</title>
</head>
<body>
    <div id="register-form">
        <h2>Register</h2>

        <form action="" method="post">
          <label for="name">Name</label>
          <input type="text" id="name" name="username" required autocomplete="off">
  
          <label for="email">Email</label>
          <input type="email" id="email" name="email" required autocomplete="off">
  
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required autocomplete="off">
          <p>Already have an account? <a href="login.php">Sign in</a></p>
          <input type="submit" name="submit" value="Register">
          
        </form>
        <?php if(isset($error_msg)): ?> 
        <p id="reg_msg"><?php echo $error_msg; ?></p>
        <?php endif; ?>
        <?php if(isset($success_msg)): ?>
        <p id="reg_msg"><?php echo $success_msg; ?></p>
        <?php endif; ?>
      </div>
    </div>

</body>
</html>