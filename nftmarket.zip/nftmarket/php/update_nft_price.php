<?php
// Start session
session_start();

// Include database connection
include_once('db_config.php');
$conn = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check if user is logged in
if(!isset($_SESSION['id'])) {
    header("Location: login.php");
}

// Get product ID and new price from form
$product_id = isset($_POST['id']) ? $_POST['id'] : '';
$new_price = isset($_POST['price']) ? $_POST['price'] : '';



// Check if product exists
$product_query = "SELECT * FROM products WHERE id = '$product_id' AND created_by_user_id = '{$_SESSION['id']}'";
$product_result = mysqli_query($conn, $product_query);
if(mysqli_num_rows($product_result) == 0) {
    // Product not found or not created by current user
    header("Location: ../index.php?error=notfound");
    exit();
}

// Update product price
$update_query = "UPDATE products SET price = '$new_price' WHERE id = '$product_id'";
if(mysqli_query($conn, $update_query)) {
    header("Location: ../index.php?success=priceupdated");
} else {
    echo "Error updating record: " . mysqli_error($conn);
    echo "Update query: " . $update_query;
    header("Location: ../index.php?error=updatefailed");
}

mysqli_close($conn);
?>
