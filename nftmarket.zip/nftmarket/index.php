<?php
    session_start();

    require_once('./php/db_config.php');
    $con = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if (!$con) {
        die("Connection Error");
    }
    // Handle search and sort queries
    if (isset($_GET['search'])) {
        $searchQuery = $_GET['search'];
        $query = "SELECT * FROM products WHERE name LIKE '%$searchQuery%'";
    } else {
        $query = "SELECT * FROM products";
    }

    if (isset($_GET['sort'])) {
        $sortBy = $_GET['sort'];
        if ($sortBy === 'price-asc') {
            $query .= " ORDER BY price ASC";
        } else if ($sortBy === 'price-desc') {
            $query .= " ORDER BY price DESC";
        } else if ($sortBy === 'name-asc') {
            $query .= " ORDER BY name ASC";
        } else if ($sortBy === 'name-desc') {
            $query .= " ORDER BY name DESC";
        }
    }

    if (isset($_SESSION['id'])) {
        $user_id = $_SESSION['id'];
    } else {
        $user_id = null;
    }

    $result = mysqli_query($con, $query);
    $nfts = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NFT Shop</title>
    <link rel="stylesheet" href="./css/header.css">
    <link rel="stylesheet" href="./css/Shop.css">
    <link rel="stylesheet" href="./css/Function.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNSliNQ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/4a94b1e09e.js" crossorigin="anonymous"></script>
</head>
<body>
<section id="header">
    <a href="index.php"><img src="img/logo.png" width="140px" height="60px"></a>
    <div>
        <ul id="navbar">
            <li><a class="active" href="">Shop</a></li>
            <?php if(!isset($_SESSION['username'])) { ?>
                <li id="login_li"><a href="html/login.php">Login</a></li>
                <li id="register_li"><a href="html/register.php">Register</a></li>
            <?php } elseif($_SESSION['auth_level'] == 1) { ?>
                <li id="moderate_li"><a href="">Moderate</a></li>
            <?php } else { ?>
                <li id="myListings_li"><a href="php/listings.php">My listings</a></li>
                <li id="profile_li"><a href="php/profile.php"><i class="fa-solid fa-user"></i> <?php echo $_SESSION['username'] ?></a></li>
                <li id="logout_li"><a href="./php/logout.php">Logout</a></li>
                <li id="basket_li"><a href=""><i onclick="toggleCart()" class="fa-solid fa-basket-shopping fa-2xl"></i></a>
                <div class="productsOnCart" id="productsOnCart" hidden>
                <div class="overlay"></div>
                <div class="top">
                    <button id="closeButton">
                        <i class="fas fa-times-circle"></i>
                    </button>
                    <h3>Cart</h3>
                </div>
                <ul id="buyItems">
                    <h4 class="empty">Your shopping cart is empty</h4>
                </ul>
                <button class="btn checkout hidden">Check out</button>
            </div>
            <?php } ?>
        </ul>
    </div>
</section>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="sort-container">
                <a href="?sort=price-asc">Sort by Price (Low to High)</a>
                <a href="?sort=price-desc">Sort by Price (High to Low)</a>
                <a href="?sort=name-asc">Sort by Name (A to Z)</a>
                <a href="?sort=name-desc">Sort by Name (Z to A)</a>
            </div>
            <?php for ($i = 0; $i < count($nfts); $i += 4): ?>
              <div class="row justify-content-center">
                <?php for ($j = $i; $j < $i + 4 && $j < count($nfts); $j++): ?>
                    <div class="col-md-3 mb-4">
                        <div class="card">
                            <img class="card-img-top" src="<?php echo $nfts[$j]['image']; ?>" alt="<?php echo $nfts[$j]['name']; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $nfts[$j]['name']; ?> <span class="id-number">#<?php echo $nfts[$j]['id']; ?></span></h5>
                                <p class="card-text">Price: <?php echo $nfts[$j]['price']; ?>€</p>
                                <?php if (isset($_SESSION['id'])): ?>
                                    <?php if ($_SESSION['id'] == $nfts[$j]['created_by_user_id']): ?>
                                      <form method="post" action="./php/update_nft_price.php">
                                        <input type="hidden" name="id" value="<?php echo $nfts[$j]['id']; ?>">
                                        <div class="form-group d-flex">
                                          <input type="number" class="form-control" id="price" name="price" step="10" value="<?php echo $nfts[$j]['price']; ?>" required>
                                        </div>
                                      </form>
                                    <?php else: ?>
                                        <button class="fa-solid fa-basket-shopping fa-2xl" data-toggle="tooltip" title="Please use 'Buy Now' button to purchase the NFT"></button>
                                        <button class="btn btn-primary buy-button" data-id="<?php echo $nfts[$j]['id']; ?>" data-name="<?php echo $nfts[$j]['name']; ?>" data-price="<?php echo $nfts[$j]['price']; ?>" data-description="<?php echo $nfts[$j]['description']; ?>">Buy Now</button>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>
              </div>
              <?php if ($j < count($nfts)): ?>
                <hr>
              <?php endif; ?>
            <?php endfor; ?>
        </div>
    </div>
</div>

<div class="search-container">
  <form action="index.php" method="GET">
    <input type="text" placeholder="Search products" name="search">
    <button type="submit"><i class="fa fa-search"></i></button>
  </form>
</div>

<script src="js/jquery-3.6.0.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/Shop.js"></script>
<script src="js/Edit.js"></script>
<script src="js/Cart.js"></script>

</body>
</html>